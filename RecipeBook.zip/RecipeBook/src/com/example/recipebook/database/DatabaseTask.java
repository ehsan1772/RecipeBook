package com.example.recipebook.database;

public enum DatabaseTask {
	FIND_CATEGORIES,
	FIND_RECIPES,
	CREATE_NEW,
	DELETE_RECIPE
}
