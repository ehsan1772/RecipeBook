package com.example.recipebook;

public enum Device {
	TABLET,
	PHONE
}
